#!/bin/sh
sleep 1 && cmatrix -C Blue
