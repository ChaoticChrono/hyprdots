flatpak run org.nickvision.cavalier
