#!/bin/sh
sleep 1 && cava
